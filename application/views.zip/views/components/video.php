<div class=" st_video_wrapper">
    <video controls autoplay muted loop id="myVideo" width="100%" class="st_video">
      <source src="<?= base_url() ?>/assets/video/8-06_italian-beds-personalizzazione.mov" type="video/mp4"> 
    </video>
	<div class="container st_video_container">
		<div class="row">
			<div class="col-lg-12 col-md-10">
				<!--=======  cta content wrapper  =======-->

				<div class="cta-content-wrapper">
					<div class="cta-content">
						<!--<h3 class="title bold-font">Find out which mattress is best</br> for you!</h3>-->
						<!--<p class="subtitle">Take your pick from our diverse range of phenomenal mattresses designed to uplift your sleep</p>-->
						<!--<a href="<?= base_url('our-products') ?>" class="theme-button cta-btn semi-bold">Compare Now</a>-->
					</div>
				</div>

				<!--=======  End of cta content wrapper  =======-->
			</div>
		</div>
	</div>
</div>

<!--====================  End of call to action area  ====================-->

