 
<?php include 'includes/header-link.php' ?>
<!--=======  header offer sticker  =======-->

<?php include 'includes/header.php' ?>
<!--====================  End of header area  ====================-->
<!--====================  hero slider area ====================-->

<!--<section class="home-banner about p-5" style="height:30vh"> -->

<!--    <div class="banner_content">-->
<!--        <h6 class="about-breadcrumbs semi-bold">User </h6>-->
<!--        <h4 class="semi-bold"> Sign in</h4>-->
<!--    </div>-->
    <!--<div class="about_image">-->
        <!--<img src="<?= base_url() ?>assets/images/Contact US.png" alt="" class="about-img">-->
        
    <!--</div>-->
<!--</section>-->
 
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item text-white"><a href="<?= base_url() ?>">Italian Beds</a></li>
    <li class="breadcrumb-item  text-white  active" aria-current="page">Sign In</li>
  </ol>
</nav>
 


<section class="contactdiv3 gray-div" style="padding-top: 50px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center bg-light p-3 ">

                <h3 class="para-text">Your order is placed succesfully</h3>
                 <p class="para-text">Order ID- 7585845assdf8dgsf15df</p>
                         
                        <a href="<?= base_url() ?>"><button class="btn btn-primary">Continue shopping</button></a>
            </div>
            
        </div>
    </div>
    </div>
</section>




<div class="lastdiv">

    <section class="clients">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <h2 class="clients_head bold-font dark_color">#DesignedForWellness</h2>
                    <p class="para_text">Speak to our expert sleep consultants and ensure all your sleep needs are met. Get their timely assistance by video, call or in-store.</p>

                    <ul>
                        <li>3/455 Scarborough Beach, Road Osborne Park, WA 6017</li>
                        <li>Monday - Friday: 9am - 6pm</li>
                        <li>Saturday Sunday: 10am - 7pm</li>
                    </ul>
                </div>
                <div class="col-lg-8">
                    <div class="row text-center ">
                        <div class="col-sm-4 text-center">
                            <img src="<?= base_url() ?>assets/images/contact-us.png" alt="">
                            <p class="margin-t dark_color">Contact Us</p>
                        </div>
                        <div class="col-sm-4 text-center">
                            <img src="<?= base_url() ?>assets/images/showroom.png" alt="">
                            <p class="margin-t dark_color">Showroom</p>
                        </div>
                        <div class="col-sm-4 text-center">
                            <img src="<?= base_url() ?>assets/images/matandpilow.png" alt="">
                            <p class="margin-t dark_color">Mattresses & Pillows</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>




<?php include 'includes/footer.php' ?>

<?php include 'includes/footer-link.php' ?>