<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $title ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--=============================================
    =            CSS  files       =
    =============================================-->

    <!-- Vendor CSS -->
    <link href="<?= base_url() ?>assets/css/faq.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/sagar.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/vendors.css" rel="stylesheet">
    <!-- Main CSS -->
    <link href="<?= base_url() ?>assets/css/style.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/css/shivani.css" rel="stylesheet">
    <!--<link href="<?= base_url() ?>assets/css/lightbox.min.css" rel="stylesheet">-->


    <!-- Revolution Slider CSS -->
    <link href="<?= base_url() ?>assets/revolution/css/settings.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/revolution/css/navigation.css" rel="stylesheet">
    <link href="<?= base_url() ?>assets/revolution/custom-setting.css" rel="stylesheet">
 
</head>

<body onload="displayCategory()">